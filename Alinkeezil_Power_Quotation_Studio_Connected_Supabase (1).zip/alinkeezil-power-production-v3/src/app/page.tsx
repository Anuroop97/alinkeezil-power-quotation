import {redirect} from "next/navigation";import {createClient} from "@/lib/supabase/server";
export default async function Home(){let destination="/login";try{const sb=await createClient();const {data:{user}}=await sb.auth.getUser();if(user)destination="/dashboard";}catch{}redirect(destination);}
