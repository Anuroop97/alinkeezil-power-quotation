import {NextResponse} from "next/server";export async function GET(){return NextResponse.json({status:"ok",service:"Alinkeezil Power Quotation Studio",version:"3.0.0"});}
