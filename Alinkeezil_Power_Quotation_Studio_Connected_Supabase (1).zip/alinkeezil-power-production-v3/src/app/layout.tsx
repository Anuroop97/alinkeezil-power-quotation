import "./globals.css";import type {Metadata} from "next";
export const metadata:Metadata={title:"Alinkeezil Power | Quotation Studio",description:"Solar quotation and proposal management."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
