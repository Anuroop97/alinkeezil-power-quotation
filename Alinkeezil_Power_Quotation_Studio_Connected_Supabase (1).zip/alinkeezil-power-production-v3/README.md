# Alinkeezil Power Quotation Studio — Production Build v3

## Included
- Next.js 15 + TypeScript application.
- Supabase SSR email/password authentication and protected dashboard.
- RLS-backed roles: admin, quotation_manager, staff.
- Customers, quotations and equipment catalogue.
- Automatic quotation reference generator.
- Editable customer, system, BOM, commercial pricing, GST, discount, subsidy, warranties, terms, milestones and projections.
- 12-section A4 PDF generator modeled on the original uploaded 12-page proposal.
- Corrected company contact information from source PDF.
- Database migration and deployment checklist.

## Connected Supabase project
- Project URL: `https://hvhipknmkhrytjhvrjpz.supabase.co`
- Region: Mumbai (`ap-south-1`)
- Administrator email: `anuroopacca21@gmail.com` (registered and assigned the `admin` role)
- `.env.local` is prefilled for this Supabase project. Keep it private and do not commit it to a public repository.

## Local setup
1. Run `npm install`.
2. Run `npm run dev`.
3. Open `http://localhost:3000/login` and sign in with your registered Supabase account.
4. For Vercel, add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` using the values in `.env.local`, and set `NEXT_PUBLIC_APP_URL` to your deployed domain..

## Deploy to Vercel
1. Push this project to a private GitHub repository.
2. Import the repository into Vercel.
3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel project environment variables.
4. Deploy a preview and test authentication, quotation CRUD and PDF output.
5. Purchase the new domain and add it in Vercel Project Settings > Domains. Follow the DNS records shown by Vercel for the specific project.
6. Update Supabase Auth Site URL and Redirect URLs to the deployed domain.

## Security before live customer data
- Disable public user signup; use admin-controlled invitations.
- Set Auth redirect URLs, SMTP and password reset settings.
- Test RLS with admin, quotation_manager, staff, inactive and anonymous accounts.
- Set up backups/PITR.
- Create private `quotation-pdfs` Storage bucket and its policies before implementing PDF archival.
- Do not expose a service-role key in browser code.
- The provided policies are for a single Alinkeezil company workspace; do not reuse them for a multi-tenant SaaS without organization scoping.
- Bank details from the original proposal are not auto-inserted into new PDFs. Add them only after company management confirms they should appear.

## Source facts retained
Original PDF: ALINKEEZIL POWER PRIVATE LIMITED; Beach Road, Near Payyambalam, Kannur, Kerala – 670001, India; general phone +91 497 270 1234; mobile +91 94474 12345; info@alinkeezilpower.com; www.alinkeezilpower.com; GSTIN 32AAACA1234Q1Z8; KSEB Class-1 EPC; MNRE Partner; founded 2012; 450+ installations; 2.8 MWp; 99.4% customer satisfaction.
Reference quote calculation: hardware ₹228,000 + installation ₹42,000 + liaisoning ₹15,000 = basic ₹285,000; GST 13.8% = ₹39,330; gross ₹324,330; discount ₹14,330; contract ₹310,000; subsidy ₹78,000; net effective outlay ₹232,000.
Source technical sizing: 9 × 550Wp = 4.95 kWp panel DC capacity with 5.0 kW inverter; source proposal labels plant 5.0 kWp. App displays both values for engineering review.
GST, subsidy, savings projections, certifications, portfolio claims, warranties and SLA must be verified/approved before issuing new customer proposals.

## Not yet deployed
This package is not connected to your Supabase or Vercel accounts. The app currently saves the PDF locally to the user's device; cloud PDF archival, immutable version history, audit log, SMTP/WhatsApp delivery and a formal automated test suite are subsequent production hardening tasks.
