create extension if not exists pgcrypto;
create sequence if not exists public.quotation_ref_seq start 418;
create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now();return new;end;$$;

create table if not exists public.user_profiles(
 user_id uuid primary key references auth.users(id) on delete cascade,
 display_name text, role text not null default 'staff' check(role in('admin','quotation_manager','staff')),
 active boolean not null default true, created_at timestamptz default now(), updated_at timestamptz default now()
);
create or replace function public.current_user_role() returns text language sql stable security definer set search_path=public
as $$ select role from public.user_profiles where user_id=auth.uid() and active=true limit 1 $$;
create or replace function public.is_active_workspace_user() returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_user_role() in('admin','quotation_manager','staff'),false) $$;
create or replace function public.can_manage_quotations() returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_user_role() in('admin','quotation_manager'),false) $$;

create table if not exists public.company_profiles(
 id uuid primary key default gen_random_uuid(), legal_name text not null default 'ALINKEEZIL POWER PRIVATE LIMITED',
 website text default 'www.alinkeezilpower.com',
 registered_address text default 'Beach Road, Near Payyambalam, Kannur, Kerala – 670001, India',
 phone text default '+91 94474 12345', general_phone text default '+91 497 270 1234',
 email text default 'info@alinkeezilpower.com', gstin text default '32AAACA1234Q1Z8',
 accreditation text default 'KSEB Class-1 EPC · MNRE Partner', founded_year text default '2012',
 installation_count text default '450+', installed_capacity text default '2.8 MWp',
 customer_satisfaction text default '99.4%', default_gst_rate numeric(7,3) default 13.8,
 quotation_prefix text default 'AP/KNR', default_validity_days integer default 30,
 created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.customers(
 id uuid primary key default gen_random_uuid(), customer_name text not null, company_name text,
 phone text, whatsapp text, email text, billing_address text, site_address text,
 district text default 'Kannur', state text default 'Kerala', pin_code text,
 customer_type text default 'Residential', created_by uuid references auth.users(id),
 created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.equipment_library(
 id uuid primary key default gen_random_uuid(), category text, item_name text not null, description text,
 manufacturer text, unit text default 'Nos.', default_quantity numeric(12,3) default 1,
 default_rate numeric(14,2) default 0, technical_standard text, active boolean default true,
 created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.quotations(
 id uuid primary key default gen_random_uuid(), quotation_ref text not null unique,
 customer_id uuid references public.customers(id) on delete set null, issue_date date not null default current_date,
 valid_until date, status text not null default 'Draft' check(status in('Draft','Under Review','Approved','Sent','Accepted','Rejected','Expired')),
 system_type text not null default 'On-grid', system_capacity_kwp numeric(10,3) default 0,
 base_value numeric(14,2) default 0, tax_rate numeric(7,3) default 0, tax_amount numeric(14,2) default 0,
 gross_value numeric(14,2) default 0, discount_amount numeric(14,2) default 0,
 contract_value numeric(14,2) default 0, subsidy_amount numeric(14,2) default 0,
 net_customer_investment numeric(14,2) default 0, proposal_data jsonb not null default '{}'::jsonb,
 created_by uuid references auth.users(id), created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists public.quotation_versions(
 id uuid primary key default gen_random_uuid(), quotation_id uuid not null references public.quotations(id) on delete cascade,
 version_number integer not null, snapshot jsonb not null, created_by uuid references auth.users(id),
 created_at timestamptz default now(), unique(quotation_id,version_number)
);
create table if not exists public.quotation_documents(
 id uuid primary key default gen_random_uuid(), quotation_id uuid not null references public.quotations(id) on delete cascade,
 storage_path text not null, file_name text not null, created_by uuid references auth.users(id), created_at timestamptz default now()
);
do $$ declare t text; begin foreach t in array array['user_profiles','company_profiles','customers','equipment_library','quotations'] loop
 execute format('drop trigger if exists set_updated_at on public.%I',t);
 execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',t);
end loop; end $$;

alter table public.user_profiles enable row level security;
alter table public.company_profiles enable row level security;
alter table public.customers enable row level security;
alter table public.equipment_library enable row level security;
alter table public.quotations enable row level security;
alter table public.quotation_versions enable row level security;
alter table public.quotation_documents enable row level security;

drop policy if exists "profile self read" on public.user_profiles;
create policy "profile self read" on public.user_profiles for select to authenticated using(user_id=auth.uid() or public.current_user_role()='admin');
drop policy if exists "profile admin write" on public.user_profiles;
create policy "profile admin write" on public.user_profiles for all to authenticated using(public.current_user_role()='admin') with check(public.current_user_role()='admin');

drop policy if exists "company read" on public.company_profiles;
create policy "company read" on public.company_profiles for select to authenticated using(public.is_active_workspace_user());
drop policy if exists "company admin write" on public.company_profiles;
create policy "company admin write" on public.company_profiles for all to authenticated using(public.current_user_role()='admin') with check(public.current_user_role()='admin');

drop policy if exists "customers access" on public.customers;
create policy "customers access" on public.customers for all to authenticated using(public.is_active_workspace_user()) with check(public.is_active_workspace_user());
drop policy if exists "equipment read" on public.equipment_library;
create policy "equipment read" on public.equipment_library for select to authenticated using(public.is_active_workspace_user());
drop policy if exists "equipment managers write" on public.equipment_library;
create policy "equipment managers write" on public.equipment_library for all to authenticated using(public.can_manage_quotations()) with check(public.can_manage_quotations());

drop policy if exists "quotes read" on public.quotations;
create policy "quotes read" on public.quotations for select to authenticated using(public.is_active_workspace_user());
drop policy if exists "quotes insert" on public.quotations;
create policy "quotes insert" on public.quotations for insert to authenticated with check(public.is_active_workspace_user() and created_by=auth.uid());
drop policy if exists "quotes update" on public.quotations;
create policy "quotes update" on public.quotations for update to authenticated using(public.can_manage_quotations() or (created_by=auth.uid() and status='Draft')) with check(public.can_manage_quotations() or (created_by=auth.uid() and status='Draft'));
drop policy if exists "quotes delete" on public.quotations;
create policy "quotes delete" on public.quotations for delete to authenticated using(public.can_manage_quotations());

drop policy if exists "versions read" on public.quotation_versions;
create policy "versions read" on public.quotation_versions for select to authenticated using(public.is_active_workspace_user());
drop policy if exists "versions insert" on public.quotation_versions;
create policy "versions insert" on public.quotation_versions for insert to authenticated with check(public.is_active_workspace_user() and created_by=auth.uid());
drop policy if exists "documents read" on public.quotation_documents;
create policy "documents read" on public.quotation_documents for select to authenticated using(public.is_active_workspace_user());
drop policy if exists "documents insert" on public.quotation_documents;
create policy "documents insert" on public.quotation_documents for insert to authenticated with check(public.is_active_workspace_user() and created_by=auth.uid());

create or replace function public.next_quotation_reference() returns text language plpgsql security definer set search_path=public as $$
declare n bigint; begin n:=nextval('public.quotation_ref_seq'); return 'AP/KNR/'||to_char(current_date,'YYYY')||'/R-'||lpad(n::text,4,'0'); end; $$;
revoke all on function public.next_quotation_reference() from public;
grant execute on function public.next_quotation_reference() to authenticated;

insert into public.company_profiles(legal_name) select 'ALINKEEZIL POWER PRIVATE LIMITED' where not exists(select 1 from public.company_profiles);
insert into public.equipment_library(category,item_name,description,manufacturer,unit,default_quantity,technical_standard)
select * from (values
('Modules','Solar PV Modules (550Wp)','Bifacial N-Type TOPCon','Waaree / Adani Solar / Tata Power Solar / Premier Energies','Nos.',9::numeric,'ALMM List-1, IEC 61215/61730, BIS certified'),
('Inverter','On-Grid String Inverter (5.0 kW)','Single phase, dual MPPT, Wi-Fi','Growatt / Solis / GoodWe / Deye','Unit',1::numeric,'IEC 62109, IEC 61727, IP65, 10-year warranty'),
('Structure','Module Mounting Structure','Anodized aluminium / HDG, Al 6063-T6','Alinkeezil Custom Engineered','Set',1::numeric,'IS 875 Part 3, SS304 fasteners, 150 km/h wind load'),
('Protection','Solar DC Distribution Box (DCDB)','1000V DC SPD, fuses, isolator','Hensel / Schneider Electric / Elmex','Unit',1::numeric,'IP65, IEC 61643-31 Type II SPD'),
('Protection','Solar AC Distribution Box (ACDB)','32A MCB, 30mA RCCB, AC SPD','Schneider Electric / L&T / Legrand','Unit',1::numeric,'IP65, IEC 61643-11, IS 8828'),
('Cable','Solar DC Cable (4.0 sq.mm)','UV-resistant, halogen-free','Polycab / Siechem / Apar Solar','Mtrs',50::numeric,'TUV 2PfG 1169 / EN 50618, tinned copper'),
('Cable','AC Armoured Cable (6.0 sq.mm)','3-core copper / heavy-duty','Polycab / Havells / Finolex','Mtrs',25::numeric,'IS 694 / IS 1554 Part 1, FRLS'),
('Earthing','Chemical Earthing System','17.2mm Cu-bonded rods + compound','Ashlok / True Power / Erico','Sets',3::numeric,'IS 3043, resistance < 2 Ohms, 2m depth'),
('Safety','Lightning Arrester & Strip','Copper ESE / spike + 25x3 GI strip','Alinkeezil Certified Safety Hardware','Set',1::numeric,'NFC 17-102 Class 1, pure copper tip'),
('BOS','Balance of System (BOS)','MC4 connectors, conduits, glands','Reputed Tier-1 Electrical Brands','Lot',1::numeric,'Flame retardant, UV stabilized, IP67')
) as v(category,item_name,description,manufacturer,unit,default_quantity,technical_standard)
where not exists(select 1 from public.equipment_library);
